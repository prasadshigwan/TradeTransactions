﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TradeTransactionsAPI.Dto;
using TradeTransactionsAPI.Persistance;
using TradeTransactionsAPI.Persistance.Entities;

namespace TradeTransactionsAPI.Controllers
{
    /// <summary>
    /// TransactionsController for doing trade transactions
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class TransactionsController : Controller
    {
        private readonly TradeTransactionDbContext _context;
        /// <summary>
        /// contructor for TransactionsController
        /// </summary>
        /// <param name="context"></param>
        public TransactionsController(TradeTransactionDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// TradeTransactionIngestions for trade Ingestions
        /// </summary>
        /// <param name="requestDto"></param>
        /// <returns></returns>
        [Route("TradeTransactionIngestions")]
        [HttpPost]
        public async Task<TransactionsResponseDto> TradeTransactionIngestions(TransactionsRequestDto requestDto)
        {
            var response = new TransactionsResponseDto();
            if (ModelState.IsValid)
            {
                try
                {
                    if (requestDto?.Action?.ToLower() == "insert")
                        await InsertTradeTransactions(requestDto, response);
                    else if (requestDto?.Action?.ToLower() == "update")
                        await UpdateTradeTransactions(requestDto, response);
                    else if (requestDto?.Action?.ToLower() == "cancel")
                        await CancelTrandeTransactions(requestDto, response);
                }
                catch (Exception ex)
                {
                    response.Status = false;
                    response.Message = "Failed to add transation";
                }
            }
            else
            {
                response.Status = false;
                response.Message = "Invalid Model";
            }
            return response;
        }

        /// <summary>
        /// CancelTrandeTransactions for cancel trade transactions
        /// </summary>
        /// <param name="requestDto"></param>
        /// <param name="response"></param>
        /// <returns></returns>
        private async Task CancelTrandeTransactions(TransactionsRequestDto requestDto, TransactionsResponseDto response)
        {
            var transaction = new Transaction()
            {
                Action = requestDto?.Action,
                Quantity = requestDto.Quantity,
                SecurityCode = requestDto?.SecurityCode,
                TradeId = requestDto.TradeId,
                TransactionOperations = requestDto?.TransactionOperations,
                Version = requestDto.Version,
                CreatedBy = "Trading_User",
                CreatedDate = DateTime.Now
            };
            _context?.Transactions.Add(transaction);
            var positions = _context?.Positions?.FirstOrDefault((m => m.SecurityCode.Trim() == requestDto.SecurityCode.Trim()));
            if (positions != null)
            {
                positions.Quantity = 0;
                positions.UpdatedBy = "Trading_User";
                positions.UpdatedDate = DateTime.Now;
                _context.Positions.Update(positions);
            }
            await _context.SaveChangesAsync();
            response.Status = true;
            response.Message = "Trade Transation saved successfully";
        }

        /// <summary>
        /// UpdateTradeTransactions for update trade transactions
        /// </summary>
        /// <param name="requestDto"></param>
        /// <param name="response"></param>
        /// <returns></returns>
        private async Task UpdateTradeTransactions(TransactionsRequestDto requestDto, TransactionsResponseDto response)
        {
            var transactionData = await _context?.Transactions?.FirstOrDefaultAsync(m => m.TradeId == requestDto.TradeId);
            if (transactionData == null)
            {
                await InsertTradeTransactions(requestDto, response);
            }
            else
            {
                var transaction = new Transaction()
                {
                    Action = requestDto?.Action,
                    Quantity = requestDto.Quantity,
                    SecurityCode = requestDto?.SecurityCode,
                    TradeId = requestDto.TradeId,
                    TransactionOperations = requestDto?.TransactionOperations,
                    Version = requestDto.Version,
                    CreatedBy = "Trading_User",
                    CreatedDate = DateTime.Now
                };
                _context?.Transactions.Add(transaction);
                await _context.SaveChangesAsync();
                var positions = _context?.Positions?.FirstOrDefault((m => m.SecurityCode.Trim() == requestDto.SecurityCode.Trim()));
                if (positions != null)
                {
                    positions.Quantity = requestDto.Quantity;
                    positions.UpdatedBy = "Trading_User";
                    positions.UpdatedDate = DateTime.Now;
                    _context.Positions.Update(positions);
                    await _context.SaveChangesAsync();
                }

                response.Status = true;
                response.Message = "Trade Transation saved successfully";
            }
        }

        /// <summary>
        /// InsertTradeTransactions for insert trade transactions
        /// </summary>
        /// <param name="requestDto"></param>
        /// <param name="response"></param>
        /// <returns></returns>
        private async Task InsertTradeTransactions(TransactionsRequestDto requestDto, TransactionsResponseDto response)
        {
            var transactionData = _context?.Transactions?.Where((m => m.SecurityCode.Trim() == requestDto.SecurityCode.Trim())).ToList();
            if (transactionData == null || transactionData.Count == 0)
            {
                var transaction = new Transaction()
                {
                    Action = requestDto?.Action,
                    Quantity = requestDto.Quantity,
                    SecurityCode = requestDto?.SecurityCode,
                    TradeId = requestDto.TradeId,
                    TransactionOperations = requestDto?.TransactionOperations,
                    Version = requestDto.Version,
                    CreatedBy = "Trading_User",
                    CreatedDate = DateTime.Now
                };
                var position = new Position()
                {
                    Quantity = requestDto.Quantity,
                    SecurityCode = requestDto?.SecurityCode,
                    TradeId = requestDto.TradeId,
                    CreatedBy = "Trading_User",
                    CreatedDate = DateTime.Now
                };
                _context?.Transactions.Add(transaction);
                _context?.Positions.Add(position);
                await _context.SaveChangesAsync();
                response.Status = true;
                response.Message = "Trade Transation saved successfully";
            }
            else
            {
                var transaction = new Transaction()
                {
                    Action = requestDto?.Action,
                    Quantity = requestDto.Quantity,
                    SecurityCode = requestDto?.SecurityCode,
                    TradeId = requestDto.TradeId,
                    TransactionOperations = requestDto?.TransactionOperations,
                    Version = requestDto.Version,
                    CreatedBy = "Trading_User",
                    CreatedDate = DateTime.Now
                };
                _context?.Transactions.Add(transaction);

                var positions = _context?.Positions?.FirstOrDefault((m => m.SecurityCode.Trim() == requestDto.SecurityCode.Trim()));
                if (positions != null)
                {
                    var quantity = 0;
                    if (requestDto.TransactionOperations.ToLower() == "buy")
                    {
                        quantity = positions.Quantity + requestDto.Quantity;
                    }
                    else if (requestDto.TransactionOperations.ToLower() == "sell")
                    {
                        quantity = positions.Quantity - requestDto.Quantity;
                    }
                    positions.Quantity = quantity;
                    positions.UpdatedBy = "Trading_User";
                    positions.UpdatedDate = DateTime.Now;
                    _context.Positions.Update(positions);
                }
                await _context.SaveChangesAsync();
                response.Status = true;
                response.Message = "Trade Transation saved successfully";
            }
        }

        /// <summary>
        /// Fetch the position Details
        /// </summary>
        /// <returns></returns>
        [Route("GetPositionList")]
        [HttpGet]
        public async Task<List<PositionDto>> GetPositionList()
        {
            var response = new List<PositionDto>();
            var positionData = await _context.Positions.ToListAsync();
            foreach (var position in positionData.ToList())
            {
                response.Add(new PositionDto()
                {
                    SecurityCode = position.SecurityCode,
                    Quantity = position.Quantity
                });
            }
            return response;
        }

    }
}
