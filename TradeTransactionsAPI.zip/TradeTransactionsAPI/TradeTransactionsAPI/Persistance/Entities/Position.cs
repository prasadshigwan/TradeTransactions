﻿using System;
using System.Collections.Generic;

namespace TradeTransactionsAPI.Persistance.Entities;

public partial class Position
{
    public int PositionId { get; set; }

    public int TradeId { get; set; }

    public string SecurityCode { get; set; } = null!;

    public int Quantity { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? UpdatedBy { get; set; }
}
