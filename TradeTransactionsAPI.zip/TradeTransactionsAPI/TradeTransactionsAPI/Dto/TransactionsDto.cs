﻿namespace TradeTransactionsAPI.Dto
{
    public class TransactionsRequestDto
    {
        //public int TransactionId { get; set; }

        public int TradeId { get; set; }

        public int Version { get; set; }

        public string SecurityCode { get; set; }

        public int Quantity { get; set; }

        public string Action { get; set; }

        public string TransactionOperations { get; set; }
    }

    public class TransactionsResponseDto
    {
        public bool Status { get; set; }

        public string Message { get; set; }
    }
}
