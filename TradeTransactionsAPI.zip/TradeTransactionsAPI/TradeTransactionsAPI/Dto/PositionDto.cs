﻿namespace TradeTransactionsAPI.Dto
{
    public class PositionDto
    {
        //public int TradeId { get; set; }
        //public int PositionId { get; set; }

        public string SecurityCode { get; set; }

        public int Quantity { get; set; }
    }
}
